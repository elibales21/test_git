package elibales_CSCI201L_Lab2;

public class Person{
	
	public String firstName;
	public void setFirstName(String fname) {
		firstName = fname;
	}
	public String getFirstName() {
		return firstName;
	}
	public String lastName;
	public void setLastName(String lname) {
		lastName = lname;
	}
	public String getLastName() {
		return lastName;
	}
	public String birthDate;
	public void setBirthdate(String bdate) {
		birthDate = bdate;
	}
	public String getBirthdate() {
		return birthDate;
	}
	
}