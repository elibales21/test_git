package elibales_CSCI201L_Lab2;

public class CommissionEmployee extends SalariedEmployee {
	public double salesTotal;
	public double commissionpercentage;
	
	public CommissionEmployee(String f, String l, String bd, int id, String title, String comp, double year_sal, double tsales, double sperc) {
		/*super.setFirstName(f);
		super.setLastName(l);
		super.setBirthdate(bd);
		super.setID(id);
		super.setTitle(title);
		super.setCompany(comp);
		yearly_salary = year_sal;*/
		super(f, l, bd, id, title, comp, year_sal);
		salesTotal = tsales;
		commissionpercentage = sperc;
	}
	
	public double getAnnualSalary() {
		return yearly_salary + (salesTotal * commissionpercentage);
	}
	
}