package elibales_CSCI201L_Lab2;

public class SalariedEmployee extends Employee {
	public double yearly_salary;
	
	public SalariedEmployee(String f, String l, String bd, int id, String title, String comp, double year_sal) {
		super.setFirstName(f);
		super.setLastName(l);
		super.setBirthdate(bd);
		super.setID(id);
		super.setTitle(title);
		super.setCompany(comp);
		yearly_salary = year_sal;
	}
	
	public double getAnnualSalary() {
		return yearly_salary;
	}
	
}