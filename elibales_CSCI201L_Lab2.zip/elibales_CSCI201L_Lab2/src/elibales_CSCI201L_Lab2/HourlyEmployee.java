package elibales_CSCI201L_Lab2;

public class HourlyEmployee extends Employee {
	
	public int wages;
	public int hours;
	public HourlyEmployee(String f, String l, String bd, int id, String title, String comp, int pay, int hrs) {
		super.setFirstName(f);
		super.setLastName(l);
		super.setBirthdate(bd);
		super.setID(id);
		super.setTitle(title);
		super.setCompany(comp);
		wages = pay;
		hours = hrs;
	}
	
	public double getAnnualSalary() {
		return wages * hours * 52;
	}
	
}