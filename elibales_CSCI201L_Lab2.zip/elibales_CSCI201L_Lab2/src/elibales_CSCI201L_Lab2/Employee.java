package elibales_CSCI201L_Lab2;

public abstract class Employee extends Person {
	public int employeeID;
	public void setID(int id) {
		employeeID = id;
	}
	public int getEmployeeID() {
		return employeeID;
	}
	
	public String jobTitle;
	public void setTitle(String title) {
		jobTitle = title;
	}
	public String getJobTitle() {
		return jobTitle;
	}
	
	public String company;
	public void setCompany(String thecompany) {
		company = thecompany;
	}
	public String getCompany() {
		return company;
	}
	
	public abstract double getAnnualSalary();
}